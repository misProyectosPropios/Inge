#include "task_lib.h"

#define WIDTH TASK_VIEWPORT_WIDTH
#define HEIGHT TASK_VIEWPORT_HEIGHT

#define SHARED_SCORE_BASE_VADDR (PAGE_ON_DEMAND_BASE_VADDR + 0xF00)
#define CANT_PONGS 3


void task(void) {
	screen pantalla;
	// ¿Una tarea debe terminar en nuestro sistema?
	while (true)
	{
	// Completar:
	// - Pueden definir funciones auxiliares para imprimir en pantalla
	// - Pueden usar `task_print`, `task_print_dec`, etc. 
		task_print(pantalla, "Pong: ", 1, 5, C_FG_CYAN);
		uint32_t* current_task_record = (uint32_t*) (SHARED_SCORE_BASE_VADDR);
		for(int task_id = 0; task_id < 3; task_id++) {
			uint32_t* jugIzq = current_task_record[task_id * 2];
			uint32_t* jugDer = current_task_record[task_id * 2 + 1];
			
			task_print_dec(pantalla, jugIzq, 3, 10, 1 + task_id * 2, C_FG_CYAN);
			task_print_dec(pantalla, jugDer, 3, 10, 1 + task_id * 2 + 1, C_FG_CYAN);
		}
		
		
		
		syscall_draw(pantalla);
	}
}

/*
void update_shared_record_score(pong* pong) {
	uint8_t task_id = ENVIRONMENT->task_id;
	uint32_t* current_task_record = (uint32_t*) (SHARED_SCORE_BASE_VADDR + ((uint32_t) task_id * sizeof(uint32_t)*2));
	current_task_record[0] = pong->player1.score;
	current_task_record[1] = pong->player2.score;
}

*/